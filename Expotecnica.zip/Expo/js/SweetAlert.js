function Mostrar(){ 

    Swal.fire(
        'Gracias por enviar tú mensaje!',
        'Te contestaremos cuando antes!',
        'success'
      )
      
}

function Membresia(){ 

    Swal.fire(
        'Gracias por obtener nuestra membresía!',
        'Sigma + aún está en desarollo, pero te mantendremos al tanto!',
        'success'
      )
      
}
